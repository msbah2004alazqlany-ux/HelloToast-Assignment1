# HelloToast Enhancements — Assignment 1

This project implements the requested three-button HelloToast enhancement using Java, view binding, and ConstraintLayout.

## Implemented
- Toast, Zero, and Count controls arranged in a left-side vertical chain beside the count display.
- Count display automatically sizes its text so the layout remains usable in portrait and landscape.
- Zero starts gray, becomes orange after the count is incremented, and returns to gray when reset.
- Count button is green for odd values and blue for even values after incrementing.
- Count state and button colors are restored after device rotation.

## Build and test
Open the `HelloToast-Assignment1` directory in Android Studio, allow Gradle sync to finish, and run the app on an emulator or device. Test the Toast message, increment through odd/even counts, reset to zero, and rotate between portrait and landscape.

Before submitting, build and test the app yourself, review the source, and follow your instructor's rules for explaining and disclosing assistance. Record the required walkthrough video yourself and upload the source project to your own public GitHub repository.
