package com.example.hellotoast;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.hellotoast.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private static final String STATE_COUNT = "count";
    private int count = 0;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (view, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left + dp(8), systemBars.top + dp(8),
                    systemBars.right + dp(8), systemBars.bottom + dp(8));
            return insets;
        });

        if (savedInstanceState != null) {
            count = savedInstanceState.getInt(STATE_COUNT, 0);
        }
        renderCountState();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setButtonColor(android.widget.Button button, int colorResource) {
        button.setBackgroundTintList(ColorStateList.valueOf(
                ContextCompat.getColor(this, colorResource)));
    }

    private void renderCountState() {
        binding.textDisplayCount.setText(String.valueOf(count));
        if (count == 0) {
            setButtonColor(binding.buttonZero, R.color.zero_inactive_gray);
        } else {
            setButtonColor(binding.buttonZero, R.color.zero_active_orange);
        }
        if (count > 0) {
            setButtonColor(binding.buttonCount,
                    count % 2 == 1 ? R.color.count_odd_green : R.color.count_even_blue);
        } else {
            binding.buttonCount.setBackgroundTintList(null);
        }
    }

    public void show_toast(View view) {
        Toast.makeText(this, R.string.hello_toast, Toast.LENGTH_SHORT).show();
    }

    public void increase_count(View view) {
        count++;
        renderCountState();
    }

    public void show_zero(View view) {
        count = 0;
        renderCountState();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt(STATE_COUNT, count);
        super.onSaveInstanceState(outState);
    }
}
